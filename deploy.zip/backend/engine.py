from typing import List, Dict, Any, Optional
from models import SimulationParams, Asset, IncomeSource, Person, BlendedStrategyParams

# ─────────────────────────────────────────────
# UK Tax Helpers (2024/25 tax year rates)
# ─────────────────────────────────────────────

PERSONAL_ALLOWANCE = 12_570
BASIC_RATE_LIMIT = 50_270
HIGHER_RATE_LIMIT = 125_140
PA_TAPER_THRESHOLD = 100_000
CGT_ANNUAL_EXEMPT = 3_000


def _effective_personal_allowance(gross_income: float) -> float:
    """Taper personal allowance above £100k (£1 lost per £2 earned over threshold)."""
    if gross_income > PA_TAPER_THRESHOLD:
        reduction = min(PERSONAL_ALLOWANCE, (gross_income - PA_TAPER_THRESHOLD) / 2)
        return max(0, PERSONAL_ALLOWANCE - reduction)
    return PERSONAL_ALLOWANCE


def calculate_uk_income_tax(income: float) -> float:
    """Compute UK income tax for the given gross income (2024/25 bands)."""
    if income <= 0:
        return 0.0

    # Inflate personal allowance is static (ignoring indexation for simplicity)
    pa = _effective_personal_allowance(income)
    taxable = max(0.0, income - pa)

    tax = 0.0
    # Basic rate 20%: taxable income up to (BASIC_RATE_LIMIT - pa)
    basic_band = max(0.0, BASIC_RATE_LIMIT - pa)
    basic = min(taxable, basic_band)
    tax += basic * 0.20
    remainder = taxable - basic

    # Higher rate 40%: up to HIGHER_RATE_LIMIT
    higher_band = HIGHER_RATE_LIMIT - BASIC_RATE_LIMIT
    higher = min(remainder, higher_band)
    tax += higher * 0.40
    remainder -= higher

    # Additional rate 45%
    tax += remainder * 0.45

    return round(tax, 2)


def calculate_uk_cgt(gains: float, taxable_income: float, is_property: bool = False) -> float:
    """Compute UK CGT on realised gains given the person's other taxable income (2024/25)."""
    net_gain = max(0.0, gains - CGT_ANNUAL_EXEMPT)
    if net_gain <= 0:
        return 0.0

    # How much basic-rate band remains after income has been stacked
    remaining_basic = max(0.0, BASIC_RATE_LIMIT - taxable_income)

    if is_property:
        rate_basic, rate_higher = 0.18, 0.24
    else:
        rate_basic, rate_higher = 0.10, 0.20

    in_basic = min(net_gain, remaining_basic)
    in_higher = net_gain - in_basic

    return round(in_basic * rate_basic + in_higher * rate_higher, 2)


DIVIDEND_ALLOWANCE = 500  # £500 for 2024/25


def calculate_uk_dividend_tax(dividends: float, taxable_income: float) -> float:
    """Compute UK dividend tax given dividends received and other taxable income (2024/25)."""
    net_dividends = max(0.0, dividends - DIVIDEND_ALLOWANCE)
    if net_dividends <= 0:
        return 0.0

    # Dividends sit on top of income; determine which rate band they fall into
    remaining_basic = max(0.0, BASIC_RATE_LIMIT - taxable_income)
    remaining_higher = max(0.0, HIGHER_RATE_LIMIT - max(BASIC_RATE_LIMIT, taxable_income))

    in_basic = min(net_dividends, remaining_basic)
    remainder = net_dividends - in_basic
    in_higher = min(remainder, remaining_higher)
    in_additional = max(0.0, remainder - remaining_higher)

    return round(in_basic * 0.0875 + in_higher * 0.3375 + in_additional * 0.3935, 2)


# ─────────────────────────────────────────────
# Asset tax treatment helpers
# ─────────────────────────────────────────────

def _is_tax_free_withdrawal(asset: Asset) -> bool:
    """ISA, Cash, and Premium Bond withdrawals are tax-free."""
    return asset.type in ("isa", "cash", "premium_bonds")


def _is_pension_withdrawal(asset: Asset) -> bool:
    return asset.type == "pension"


def _is_cgt_asset(asset: Asset) -> bool:
    """GIA, RSU withdrawals are subject to CGT."""
    return asset.type in ("general", "rsu")


def _is_property_cgt(asset: Asset) -> bool:
    return asset.type == "property"


# ─────────────────────────────────────────────
# Main simulation
# ─────────────────────────────────────────────

def calculate_total_balance(assets: List[Asset]) -> float:
    return sum(a.balance for a in assets)


def run_simulation(params: SimulationParams) -> Dict[str, Any]:
    current_age = params.current_age
    retirement_age = params.retirement_age
    life_expectancy = params.life_expectancy
    inflation_rate = params.inflation_rate / 100.0

    # Build lookup: person_id -> Person
    people = {p.id: p for p in params.people}

    # Track remaining tax-free pension cash per person (2024/25 lifetime limit: £268,275)
    PENSION_TAX_FREE_LIFETIME_LIMIT = 268_275.0
    person_tax_free_remaining: Dict[str, float] = {
        pid: PENSION_TAX_FREE_LIFETIME_LIMIT for pid in people
    }

    assets = [Asset(**a.model_dump()) for a in params.assets]

    yearly_data = []

    for age in range(current_age, life_expectancy + 1):

        # 1. Required (inflation-adjusted) income
        years_inflated = age - current_age
        required_income = params.desired_annual_income * ((1 + inflation_rate) ** years_inflated)

        # 2. Scheduled income sources
        generated_income = 0.0
        income_breakdown: Dict[str, float] = {}

        # Per-person taxable income, CGT gains, and dividend accumulators
        person_taxable_income: Dict[str, float] = {pid: 0.0 for pid in people}
        person_cgt_gains: Dict[str, float] = {pid: 0.0 for pid in people}
        person_cgt_property_gains: Dict[str, float] = {pid: 0.0 for pid in people}
        person_dividend_income: Dict[str, float] = {pid: 0.0 for pid in people}

        # Track sources for proportional tax allocation
        person_source_taxable: Dict[str, Dict[str, float]] = {pid: {} for pid in people}
        person_source_cgt: Dict[str, Dict[str, float]] = {pid: {} for pid in people}
        person_source_property_cgt: Dict[str, Dict[str, float]] = {pid: {} for pid in people}
        person_source_dividends: Dict[str, Dict[str, float]] = {pid: {} for pid in people}

        for inc in params.incomes:
            if inc.start_age <= age <= inc.end_age:
                years_elapsed = age - current_age
                inflated_inc = inc.amount * ((1 + inflation_rate) ** years_elapsed)
                generated_income += inflated_inc
                income_breakdown[inc.name] = inflated_inc

                # Attribute income to owning person
                if inc.person_id and inc.person_id in people:
                    pid = inc.person_id
                    person_taxable_income[pid] += inflated_inc
                    person_source_taxable[pid][inc.name] = person_source_taxable[pid].get(inc.name, 0.0) + inflated_inc
            else:
                income_breakdown[inc.name] = 0.0

        # 3. Apply growth and contributions to assets
        for asset in assets:
            growth = asset.balance * (asset.annual_growth_rate / 100.0)
            asset.balance += growth
            if age < retirement_age:
                asset.balance += asset.annual_contribution

        # 3b. Attribute GIA dividends (taxable each year regardless of retirement)
        for asset in assets:
            if asset.type == "general" and asset.dividend_yield:
                dividends = asset.balance * (asset.dividend_yield / 100.0)
                
                # Dividends contribute to generated income
                generated_income += dividends
                src_name = f"Dividends: {asset.name}"
                income_breakdown[src_name] = dividends

                if not asset.owners:
                    if people:
                        pid = next(iter(people))
                        person_dividend_income[pid] += dividends
                        person_source_dividends[pid][src_name] = person_source_dividends[pid].get(src_name, 0.0) + dividends
                else:
                    for ownership in asset.owners:
                        pid = ownership.person_id
                        if pid in people:
                            share_amount = dividends * ownership.share
                            person_dividend_income[pid] += share_amount
                            person_source_dividends[pid][src_name] = person_source_dividends[pid].get(src_name, 0.0) + share_amount

        # 4. Withdraw from assets to cover income shortfall
        shortfall = max(0.0, required_income - generated_income)

        if shortfall > 0:
            if age < retirement_age:
                # ── Pre-Retirement Strategy ──
                # Only use cash, premium_bonds, rsu, general (no ISA or Pension)
                allowed_types = {"cash", "premium_bonds", "rsu", "general"}
                withdrawable_assets = [a for a in assets if a.is_withdrawable and a.type in allowed_types]
                priority_map = {ptype: i for i, ptype in enumerate(params.withdrawal_priority)}
                sorted_assets = sorted(withdrawable_assets, key=lambda a: priority_map.get(a.type, 999))
                remaining_shortfall = shortfall
                for asset in sorted_assets:
                    if remaining_shortfall <= 0:
                        break
                    if asset.balance > 0:
                        max_draw = (
                            asset.max_annual_withdrawal
                            if asset.max_annual_withdrawal is not None
                            else float("inf")
                        )
                        withdrawal = min(asset.balance, remaining_shortfall, max_draw)
                        asset.balance -= withdrawal
                        remaining_shortfall -= withdrawal
                        generated_income += withdrawal
                        src_name = f"Withdrawal: {asset.name}"
                        income_breakdown[src_name] = income_breakdown.get(src_name, 0.0) + withdrawal
                        
                        if not asset.owners:
                            if people:
                                pid = next(iter(people))
                                _attribute_withdrawal_tax_with_sources(
                                    pid, withdrawal, asset, src_name,
                                    person_taxable_income, person_cgt_gains, person_cgt_property_gains,
                                    person_tax_free_remaining,
                                    person_source_taxable, person_source_cgt, person_source_property_cgt
                                )
                        else:
                            for ownership in asset.owners:
                                pid = ownership.person_id
                                if pid not in people:
                                    continue
                                share_amount = withdrawal * ownership.share
                                _attribute_withdrawal_tax_with_sources(
                                    pid, share_amount, asset, src_name,
                                    person_taxable_income, person_cgt_gains, person_cgt_property_gains,
                                    person_tax_free_remaining,
                                    person_source_taxable, person_source_cgt, person_source_property_cgt
                                )
            else:
                use_blended = (params.withdrawal_strategy == "blended")
                bp = params.blended_params or BlendedStrategyParams()

            if use_blended:
                # ── Blended Tax-Optimised Strategy ──
                # Step A: Draw isa_drawdown_pct% from each ISA (tax-free)
                isa_assets = [a for a in assets if a.type == "isa" and a.is_withdrawable and a.balance > 0]
                for asset in isa_assets:
                    if shortfall <= 0:
                        break
                    draw_target = asset.balance * (bp.isa_drawdown_pct / 100.0)
                    withdrawal = min(asset.balance, draw_target, shortfall)
                    if withdrawal > 0:
                        asset.balance -= withdrawal
                        shortfall -= withdrawal
                        generated_income += withdrawal
                        src_name = f"Withdrawal: {asset.name}"
                        income_breakdown[src_name] = income_breakdown.get(src_name, 0.0) + withdrawal
                        # ISA is tax-free — no tax attribution needed, but track ownership
                        if not asset.owners:
                            pass  # tax-free, no attribution
                        else:
                            for ownership in asset.owners:
                                pid = ownership.person_id
                                if pid not in people:
                                    continue
                                # ISA withdrawals are tax-free, no _attribute call

                # Step B: Draw pension_drawdown_pct% from each DC pension (taxable)
                pension_assets = [a for a in assets if a.type == "pension" and a.is_withdrawable and a.balance > 0]
                isa_topup_remaining = bp.isa_topup_from_pension  # £20k default
                for asset in pension_assets:
                    if shortfall <= 0 and isa_topup_remaining <= 0:
                        break
                    draw_target = asset.balance * (bp.pension_drawdown_pct / 100.0)
                    # Maximum useful draw is what's needed for the shortfall PLUS what we can recycle into ISA
                    max_useful_draw = shortfall + isa_topup_remaining
                    pension_draw = min(draw_target, max_useful_draw)
                    
                    withdrawal = min(asset.balance, pension_draw)
                    if withdrawal <= 0:
                        continue
                    
                    asset.balance -= withdrawal
                    generated_income += withdrawal
                    src_name = f"Withdrawal: {asset.name}"
                    income_breakdown[src_name] = income_breakdown.get(src_name, 0.0) + withdrawal

                    # Tax attribution for pension withdrawal
                    if not asset.owners:
                        if people:
                            pid = next(iter(people))
                            _attribute_withdrawal_tax_with_sources(
                                pid, withdrawal, asset, src_name,
                                person_taxable_income, person_cgt_gains, person_cgt_property_gains,
                                person_tax_free_remaining,
                                person_source_taxable, person_source_cgt, person_source_property_cgt
                            )
                    else:
                        for ownership in asset.owners:
                            pid = ownership.person_id
                            if pid not in people:
                                continue
                            share_amount = withdrawal * ownership.share
                            _attribute_withdrawal_tax_with_sources(
                                pid, share_amount, asset, src_name,
                                person_taxable_income, person_cgt_gains, person_cgt_property_gains,
                                person_tax_free_remaining,
                                person_source_taxable, person_source_cgt, person_source_property_cgt
                            )

                    # Step C: Recycle part of the pension drawdown into ISA (up to £20k/yr)
                    topup = 0.0
                    if isa_topup_remaining > 0 and isa_assets:
                        topup = min(withdrawal, isa_topup_remaining)
                        # Top up the first ISA found
                        isa_assets[0].balance += topup
                        isa_topup_remaining -= topup
                        income_breakdown[f"ISA Top-up (from {asset.name})"] = income_breakdown.get(f"ISA Top-up (from {asset.name})", 0.0) + topup

                    # The remaining withdrawal goes towards satisfying the lifestyle shortfall
                    covers_shortfall = withdrawal - topup
                    if covers_shortfall > 0:
                        shortfall -= covers_shortfall

                # Step D: If still shortfall, fall back to sequential priority for remaining gap
                if shortfall > 0:
                    withdrawable_assets = [a for a in assets if a.is_withdrawable]
                    priority_map = {ptype: i for i, ptype in enumerate(params.withdrawal_priority)}
                    sorted_assets = sorted(withdrawable_assets, key=lambda a: priority_map.get(a.type, 999))
                    remaining_shortfall = shortfall
                    for asset in sorted_assets:
                        if remaining_shortfall <= 0:
                            break
                        if asset.balance > 0:
                            max_draw = (
                                asset.max_annual_withdrawal
                                if asset.max_annual_withdrawal is not None
                                else float("inf")
                            )
                            withdrawal = min(asset.balance, remaining_shortfall, max_draw)
                            asset.balance -= withdrawal
                            remaining_shortfall -= withdrawal
                            generated_income += withdrawal
                            src_name = f"Withdrawal: {asset.name}"
                            income_breakdown[src_name] = income_breakdown.get(src_name, 0.0) + withdrawal
                            if not asset.owners:
                                if people:
                                    pid = next(iter(people))
                                    _attribute_withdrawal_tax_with_sources(
                                        pid, withdrawal, asset, src_name,
                                        person_taxable_income, person_cgt_gains, person_cgt_property_gains,
                                        person_tax_free_remaining,
                                        person_source_taxable, person_source_cgt, person_source_property_cgt
                                    )
                            else:
                                for ownership in asset.owners:
                                    pid = ownership.person_id
                                    if pid not in people:
                                        continue
                                    share_amount = withdrawal * ownership.share
                                    _attribute_withdrawal_tax_with_sources(
                                        pid, share_amount, asset, src_name,
                                        person_taxable_income, person_cgt_gains, person_cgt_property_gains,
                                        person_tax_free_remaining,
                                        person_source_taxable, person_source_cgt, person_source_property_cgt
                                    )

            else:
                # ── Sequential (original) Strategy ──
                withdrawable_assets = [a for a in assets if a.is_withdrawable]
                priority_map = {ptype: i for i, ptype in enumerate(params.withdrawal_priority)}
                sorted_assets = sorted(withdrawable_assets, key=lambda a: priority_map.get(a.type, 999))

                remaining_shortfall = shortfall
                for asset in sorted_assets:
                    if remaining_shortfall <= 0:
                        break
                    if asset.balance > 0:
                        max_draw = (
                            asset.max_annual_withdrawal
                            if asset.max_annual_withdrawal is not None
                            else float("inf")
                        )
                        withdrawal = min(asset.balance, remaining_shortfall, max_draw)
                        asset.balance -= withdrawal
                        remaining_shortfall -= withdrawal
                        generated_income += withdrawal
                        src_name = f"Withdrawal: {asset.name}"
                        income_breakdown[src_name] = withdrawal

                        # ── Tax attribution by ownership ──
                        if not asset.owners:
                            if people:
                                pid = next(iter(people))
                                _attribute_withdrawal_tax_with_sources(
                                    pid, withdrawal, asset, src_name,
                                    person_taxable_income, person_cgt_gains, person_cgt_property_gains,
                                    person_tax_free_remaining,
                                    person_source_taxable, person_source_cgt, person_source_property_cgt
                                )
                        else:
                            for ownership in asset.owners:
                                pid = ownership.person_id
                                if pid not in people:
                                    continue
                                share_amount = withdrawal * ownership.share
                                _attribute_withdrawal_tax_with_sources(
                                    pid, share_amount, asset, src_name,
                                    person_taxable_income, person_cgt_gains, person_cgt_property_gains,
                                    person_tax_free_remaining,
                                    person_source_taxable, person_source_cgt, person_source_property_cgt
                                )

        # 5. Compute tax per person and proportionally attribute to sources
        person_tax: Dict[str, Dict[str, float]] = {}
        tax_by_source: Dict[str, float] = {}

        for pid, person in people.items():
            taxable_inc = person_taxable_income[pid]
            cgt_gains = person_cgt_gains[pid]
            prop_gains = person_cgt_property_gains[pid]
            dividends = person_dividend_income[pid]

            income_tax = calculate_uk_income_tax(taxable_inc)
            cgt = calculate_uk_cgt(cgt_gains, taxable_inc, is_property=False)
            property_cgt = calculate_uk_cgt(prop_gains, taxable_inc + cgt_gains, is_property=True)
            dividend_tax = calculate_uk_dividend_tax(dividends, taxable_inc)

            # Proportional allocation
            if taxable_inc > 0:
                for src_name, amount in person_source_taxable[pid].items():
                    tax_by_source[src_name] = tax_by_source.get(src_name, 0.0) + (income_tax * (amount / taxable_inc))
            
            if cgt_gains > 0:
                for src_name, amount in person_source_cgt[pid].items():
                    tax_by_source[src_name] = tax_by_source.get(src_name, 0.0) + (cgt * (amount / cgt_gains))

            if prop_gains > 0:
                for src_name, amount in person_source_property_cgt[pid].items():
                    tax_by_source[src_name] = tax_by_source.get(src_name, 0.0) + (property_cgt * (amount / prop_gains))

            if dividends > 0:
                for src_name, amount in person_source_dividends[pid].items():
                    tax_by_source[src_name] = tax_by_source.get(src_name, 0.0) + (dividend_tax * (amount / dividends))

            person_tax[person.name] = {
                "income_tax": income_tax,
                "cgt": cgt,
                "property_cgt": property_cgt,
                "dividend_tax": dividend_tax,
                "total": round(income_tax + cgt + property_cgt + dividend_tax, 2),
                "taxable_income": round(taxable_inc, 2),
                "cgt_gains": round(cgt_gains, 2),
                "dividends": round(dividends, 2),
            }

        # Round the tax by source mappings
        for k in tax_by_source:
            tax_by_source[k] = round(tax_by_source[k], 2)

        # Find any life events occurring this year
        events_this_year = [evt.name for evt in params.life_events if evt.age == age]

        # 6. Record state for this year
        year_record = {
            "age": age,
            "required_income": required_income,
            "total_income": generated_income, # renamed properly
            "total_assets": calculate_total_balance(assets),
            "asset_balances": {a.name: a.balance for a in assets},
            "income_breakdown": income_breakdown,
            "tax_by_source": tax_by_source,
            "shortfall_remaining": max(0.0, required_income - generated_income),
            "tax_breakdown": person_tax,
            "life_events": events_this_year,
        }
        yearly_data.append(year_record)

    return {
        "params": params.model_dump(),
        "timeline": yearly_data,
    }


def _attribute_withdrawal_tax_with_sources(
    pid: str,
    amount: float,
    asset: Asset,
    src_name: str,
    person_taxable_income: Dict[str, float],
    person_cgt_gains: Dict[str, float],
    person_cgt_property_gains: Dict[str, float],
    person_tax_free_remaining: Dict[str, float],
    person_source_taxable: Dict[str, Dict[str, float]],
    person_source_cgt: Dict[str, Dict[str, float]],
    person_source_property_cgt: Dict[str, Dict[str, float]]
) -> None:
    """Attribute withdrawal to the correct tax bucket for a person."""
    if _is_tax_free_withdrawal(asset):
        pass  # ISA, cash – no tax
    elif _is_pension_withdrawal(asset):
        # Apply 25% tax-free allowance (UFPLS) up to the £268,275 lifetime limit
        tax_free_available = person_tax_free_remaining.get(pid, 0.0)
        tax_free_portion = min(amount * 0.25, tax_free_available)
        taxable_portion = amount - tax_free_portion
        person_tax_free_remaining[pid] = tax_free_available - tax_free_portion
        person_taxable_income[pid] += taxable_portion
        person_source_taxable[pid][src_name] = person_source_taxable[pid].get(src_name, 0.0) + taxable_portion
    elif _is_cgt_asset(asset):
        person_cgt_gains[pid] += amount
        person_source_cgt[pid][src_name] = person_source_cgt[pid].get(src_name, 0.0) + amount
    elif _is_property_cgt(asset):
        person_cgt_property_gains[pid] += amount
        person_source_property_cgt[pid][src_name] = person_source_property_cgt[pid].get(src_name, 0.0) + amount
